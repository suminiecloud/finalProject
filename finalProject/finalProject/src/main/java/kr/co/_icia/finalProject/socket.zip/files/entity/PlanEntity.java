package kr.co._icia.finalProject.socket.files.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import kr.co._icia.finalProject.entity.Members;
import kr.co._icia.finalProject.socket.files.dto.PlanDto;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter @Entity
@Table(name="PLAN")
public class PlanEntity {
  
  @Id
  @GeneratedValue
  private Long id;
  
  private String pname;

  private String pstartdate;
  private String penddate;
  
  @ManyToOne
  @JoinColumn(name = "member_id")
  private Members member;
  
  @OneToMany(mappedBy = "plan")
  private List<PlanDetailEntity> planDetailList = new ArrayList<>();  
  
  public static PlanEntity createPlans(PlanDto planDto, Members members) {
    PlanEntity plan = new PlanEntity();
    plan.setPstartdate(planDto.getPbasedate());
    plan.setPenddate(planDto.getPenddate());
    plan.setMember(members);
    return plan;
  }

}
