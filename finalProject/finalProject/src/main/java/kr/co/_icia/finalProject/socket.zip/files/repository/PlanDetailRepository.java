package kr.co._icia.finalProject.socket.files.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import kr.co._icia.finalProject.socket.files.entity.PlanDetailEntity;
import kr.co._icia.finalProject.socket.files.entity.PlanEntity;

public interface PlanDetailRepository extends JpaRepository<PlanDetailEntity, Long>{

  @Query("SELECT b FROM plandetail b WHERE b.member.id = :id")
  List<PlanDetailEntity> findByMemberId(@Param("id") Long id);
  /* SELECT P.*, M.*
     FROM PLANDETAIL P
        INNER JOIN MEMBERS M
        ON P.MEMBER_ID = M.ID
     WHERE M.MID = 'a';*/

}
