package kr.co._icia.finalProject.socket.files.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import kr.co._icia.finalProject.socket.files.entity.PlanEntity;

public interface PlansRepository extends JpaRepository<PlanEntity, Long>{

  @Query("SELECT b FROM plan p WHERE p.member.id = :id")
  List<PlanEntity> findByMemberId(@Param("loginId") Long loginId);

}
