package kr.co._icia.finalProject.socket;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import kr.co._icia.finalProject.dto.MemberJoinForm;
import kr.co._icia.finalProject.entity.Members;
import kr.co._icia.finalProject.service.MemberService;
import kr.co._icia.finalProject.socket.files.dto.PlanDetailDto;
import kr.co._icia.finalProject.socket.files.dto.PlanDto;
import kr.co._icia.finalProject.socket.files.entity.PlanDetailEntity;
import kr.co._icia.finalProject.socket.files.entity.PlanEntity;
import kr.co._icia.finalProject.socket.files.entity.ShareContent;

@Controller
@RequestMapping("/members")
public class TestSocketController {

  @Autowired
  private MemberService memberService;

  @Autowired
  private HttpSession session;

  @Autowired
  private TestSocketService testService;
  
  @Autowired
  private ShareContentService shareService;

  @GetMapping("/testHome")
  public String testHome() {
    return "member/testHome";
  }
  
  // 로그인 안되어있을 때 공유받은 일정 확인
  @GetMapping("/receiveShareContents")
  public String receiveShareContents(@RequestParam("shareContentId") Long[] shareIdList, Model model) {
    List<PlanEntity> planList = new ArrayList<>();
    for(Long scId : shareIdList) {
      ShareContent shareContent = shareService.findById(scId);
      shareService.updateState(shareContent);
      PlanEntity sharePlan = shareContent.getPlanId();
      planList.add(sharePlan);
    }
    model.addAttribute("planList", planList);
    return "member/receivePlanView";
  }

  // 로그인 되어있을 때 공유받은 일정 확인
  @GetMapping("/receivePlanView")
  public String receivePlanView(@RequestParam("receivePlan") Long[] planId, Model model, @RequestParam("sendMid") String sendmid) {
    // 알림 보낸 회원
    Members sendMember = memberService.findBymid(sendmid);
    if(sendMember != null) {
      model.addAttribute("sendMember", sendMember);
    }
    // sendMid=a&receivePlan=1&receivePlan=25&receivePlan=3
    // List<PlanDetailEntity> planDetailList = plan.getPlanDetailList();
    
    List<PlanEntity> planList = testService.findByAllPlan(planId);
    
    model.addAttribute("planList", planList);
    
    return "member/receivePlanView";
  }

  @GetMapping("/sharePlanToMember")
  public String sharePlanToMember(@RequestParam("mid") String[] targetMid, @RequestParam("planid") Long[] planId) {
    // planIdArray
    testService.sharePlanToMember(targetMid, planId);

    return "redirect:/members/viewPlan";
  }

  @GetMapping("/searchMember")
  @ResponseBody
  public List<MemberJoinForm> searchMember(@RequestParam("mid") String memberId) {
    List<Members> members = memberService.findByMidLike(memberId);
    if(members == null) {
      return new ArrayList<>();
    }
    List<MemberJoinForm> memberList = new ArrayList<>();
    for(int i = 0; i < members.size(); i++) {
      MemberJoinForm mf = new MemberJoinForm();
      mf.setMid(members.get(i).getMid());
      mf.setMpw(members.get(i).getMpw());
      mf.setMname(members.get(i).getMname());
      memberList.add(mf);
    }
    return memberList;
  }

  @GetMapping("/memberShare")
  public String memberShare(@RequestParam("memId") Long memId) {
    Members members = memberService.findById(memId);
    if (members != null) {
      // planWebSocketHandler.memberSharePlan(memId)
    }
    return "redirect:/members/viewPlan";
  }

  // 날짜 선택
  @GetMapping("/writeDate")
  public String writeDatePage() {
    return "member/chooseDate";
  }

  // 날짜 등록 기능
  @PostMapping("/writeDate")
  public String registPlan(PlanDto planDto, Model model, @RequestParam("pname") String planName) {
    Long loginId = (Long) session.getAttribute("loginId");
    if (loginId != null) {
      PlanEntity planEntity = testService.registDates(planDto, loginId, planName);
      model.addAttribute("planEntity", planEntity.getId());
      model.addAttribute("startDate", planEntity.getPstartdate());
      model.addAttribute("endDate", planEntity.getPenddate());
    }
    return "member/detailForm";
  }

  // 일정작성
  @PostMapping("/writePlan")
  public String memberWritePlan(PlanDetailDto planDetail, @RequestParam("planId") Long planid) {
    String loginMid = (String) session.getAttribute("loginMid");
    Members members = memberService.findByMidCheck(loginMid);
    if (members != null) {

      testService.registPlan(planDetail, members, planid);
    }
    return "redirect:/members/testHome";
  }

  // 내 일정 보기
  @GetMapping("/viewPlan")
  public String viewPlanPage(Model model) {
    System.out.println("내 일정 보기 페이지 이동");
    Long loginId = (Long) session.getAttribute("loginId");
    if (loginId != null) {
      List<PlanEntity> myPlanList = testService.findPlanList(loginId);
      model.addAttribute("myPlanList", myPlanList);
    }
    List<Members> memberList = memberService.findAll();
    model.addAttribute("memberList", memberList);
    return "member/myPlanView";
  }

  // 내 세부일정 보기
  @GetMapping("/detailViewPlan/{pid}")
  public String memberViewPlan(@PathVariable("pid") Long planId, Model model) {
    String loginMid = (String) session.getAttribute("loginMid");
    PlanEntity plan = testService.findPlanById(planId);
    List<PlanDetailEntity> planDetailList = plan.getPlanDetailList();
    model.addAttribute("detailList", planDetailList);
    return "member/myDetailPlanView";
  }

  @GetMapping("/join")
  public String joinPage(Model model) {
    MemberJoinForm memberJoinForm = new MemberJoinForm();
    model.addAttribute("memberJoinForm", memberJoinForm);
    return "member/joinForm";
  }

  @PostMapping("/join")
  public String memberJoin(@Valid MemberJoinForm memberJoinForm, BindingResult result, Model model) {
    model.addAttribute("memberJoinForm", memberJoinForm);
    /* 회원 아이디 중복 확인 */
    if (!result.hasFieldErrors("mid")) { // mid에 Error가 없는 경우
      // 아이디로 회원 정보 조회
      Members checkMember = memberService.findByMidCheck(memberJoinForm.getMid());
      if (checkMember != null) { // 회원 정보가 조회 되는 경우
        // 중복 확인 Error 추가
        result.rejectValue("mid", "duplicateMid", "이미 사용중인 아이디 입니다.");
      }
    }
    /* 유효성검사 */
    if (result.hasErrors()) { // Error가 확인 된 경우
      return "member/joinForm";
    }

    /* 회원 등록 기능 호출 */
    try {
      Members member = Members.createMembers(memberJoinForm);
      memberService.registMember(member);
    } catch (Exception e) {
      e.printStackTrace();
      // model.addAttribute("memberForm", memberForm);
      return "member/joinForm";
    }

    return "member/testHome"; // redirect - 회원 목록 페이지 이동 요청

  }

  /* 로그인 페이지 이동 */
  @GetMapping("/login")
  public String memberLoginPage() {
    return "member/loginForm";
  }

  /* 로그인 기능 */
  @PostMapping("/login")
  public String memberLogin(@RequestParam("mid") String mid, @RequestParam("mpw") String mpw, Model model) {
    Members loginMember = memberService.findByMidAndMpw(mid, mpw);
    System.out.println("loginMember" + loginMember.getMid());
    if (loginMember != null) {
      session.setAttribute("loginMid", loginMember.getMid());
      session.setAttribute("loginId", loginMember.getId());
      // 상태가 0인 sharecontent를 찾아
      List<ShareContent> receivePlanList = shareService.findSharePlanList(loginMember.getId());
      // model에 저장해
      model.addAttribute("shareContentCnt",receivePlanList.size());
      System.out.println("receiveMidList : " + receivePlanList.size());
      model.addAttribute("receivePlanList", receivePlanList);
     //  model.addAttribute("receiveMidList", receiveMidList);
      /* 클라이언트에게 로그인 알림 전송 기능 호출 */
      // memberWebSocketHandler.memberAlert(loginMember.getMid());
      return "member/testHome";
    }
    return "member/loginForm";
  }

  // 로그아웃
  @GetMapping("/logout")
  public String memberLogout() {
    session.removeAttribute("loginMid");
    session.removeAttribute("loginId");
    return "member/testHome";
  }
}
