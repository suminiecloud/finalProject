package kr.co._icia.finalProject.socket;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co._icia.finalProject.entity.Members;
import kr.co._icia.finalProject.socket.files.entity.ShareContent;
import kr.co._icia.finalProject.socket.files.repository.ShareContentRepository;

@Service
public class ShareContentService {

	@Autowired
	private ShareContentRepository contentRepository;

//	public void registMember(ShareContent content) {
//		contentRepository.save(content);
//	}
//	
//	
//	public List<ShareContent> findContents() {
//		List<ShareContent> contentList = contentRepository.findAll();
//		return contentList;
//	}
//
	public List<ShareContent> findSharePlanList(Long reciveMemberId) {
	  
		List<ShareContent> contentList = contentRepository.findByMembersId(reciveMemberId);
		
		return contentList;
	}

  public ShareContent findById(Long scId) {
    return contentRepository.findById(scId).orElse(null);
  }
	
	public void updateState(ShareContent content) {
		ShareContent updateContent = new ShareContent();
		updateContent = content;
		updateContent.setCheckState(1);
		
		contentRepository.save(updateContent);
	}	
}