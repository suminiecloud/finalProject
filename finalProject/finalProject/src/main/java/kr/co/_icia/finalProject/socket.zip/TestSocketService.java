package kr.co._icia.finalProject.socket;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpSession;
import kr.co._icia.finalProject.dto.MemberJoinForm;
import kr.co._icia.finalProject.entity.Members;
import kr.co._icia.finalProject.repository.MemberRepository;
import kr.co._icia.finalProject.socket.files.dto.PlanDetailDto;
import kr.co._icia.finalProject.socket.files.dto.PlanDto;
import kr.co._icia.finalProject.socket.files.entity.PlanDetailEntity;
import kr.co._icia.finalProject.socket.files.entity.PlanEntity;
import kr.co._icia.finalProject.socket.files.entity.ShareContent;
import kr.co._icia.finalProject.socket.files.repository.PlanDetailRepository;
import kr.co._icia.finalProject.socket.files.repository.PlansRepository;
import kr.co._icia.finalProject.socket.files.repository.ShareContentRepository;

@Service
public class TestSocketService {

  @Autowired
  private PlanDetailRepository planDetailrep;

  @Autowired
  private PlanWebSocketHandler planWebSocketHandler;

  @Autowired
  private PlansRepository planRepository;

  @Autowired
  private MemberRepository memberRepository;

  @Autowired
  private ShareToMemberHandler shareToMemberHandler;

  @Autowired
  private HttpSession session;

  @Autowired
  private ShareContentRepository shareRepository;

  @Autowired
  private ShareContentService shareSerivce;

  public void registPlan(PlanDetailDto planDetail, Members members, Long planId) {
    PlanEntity planEntity = planRepository.findById(planId).orElse(null);
    PlanDetailEntity planDetailEntity = PlanDetailEntity.createPlan(planDetail, members, planEntity);
    planDetailrep.save(planDetailEntity);
    planWebSocketHandler.sharePlans(planEntity.getId(), members.getId());
  }

  public PlanEntity getPlanListById(Long findPlanId) {
    PlanEntity planEntity = planRepository.findById(findPlanId).orElse(null);
    return planEntity;
  }

//  public void registplanDate(PlanDto planDto, Members members) {
//    PlanEntity planEntity = PlanEntity.createPlans(planDto, members);
//    planRepository.save(planEntity);
//    planWebSocketHandler.sharePlans(planEntity.getId(), members.getId());
//  }

  public PlanEntity registDates(PlanDto planDto, Long loginId, String planName) {
    // 회원 조회
    Members members = memberRepository.findById(loginId).orElse(null);

    // planEntity 생성
    PlanEntity planEntity = PlanEntity.createPlans(planDto, members);
    planEntity.setPname(planName);
    System.out.println(planEntity.getPstartdate());
    System.out.println(planEntity.getPenddate());
    planRepository.save(planEntity);

    return planEntity;
  }

  public List<PlanEntity> findPlanList(Long loginId) {
    return planRepository.findByMemberId(loginId);
  }

  public void sharePlanToMember(String[] targetMid, Long[] planIdList) {
    // 1. share 테이블 save;
    String sendMid = (String) session.getAttribute("loginMid");
    Members sendMemberId = memberRepository.findByMid(sendMid);

    for (String receiveMid : targetMid) {
      Members receiveMemberId = memberRepository.findByMid(receiveMid);
      for (Long planId : planIdList) {
        ShareContent shareContent = new ShareContent();
        shareContent.setSendMemberId(sendMemberId);
        shareContent.setReceiveMemberId(receiveMemberId);
        PlanEntity plan = planRepository.findById(planId).orElse(null);
        shareContent.setPlanId(plan);

        shareRepository.save(shareContent);
      }
    }
    // 2. 메세지 전송
    shareToMemberHandler.sendPlanToMember(sendMid, targetMid, planIdList);
    
//    for (Members receiveMember : receiveMemberIdList) {
//      ShareContent sc = shareRepository.findByReceivememberid(receiveMember);
//      if (sc.getCheckState() == 0) {
//        shareSerivce.updateState(sc);
//      }
//    }
  }

//  public void getPlanListById(String[] targetMid, Long[] planId) {
//    String sendMid = (String) session.getAttribute("loginMid");
//    Members members = memberRepository.findByMid(sendMid);
//    MemberJoinForm sendMember = new MemberJoinForm();
//    sendMember.setMid(members.getMid());
//    if(members != null) {
//      shareToMemberHandler.sendPlanToMember(sendMember.getMid(), targetMid, planId);
//    }
//  }

  public List<PlanEntity> findByAllPlan(Long[] planId) {
    List<PlanEntity> detailList = new ArrayList<>();
    for (int i = 0; i < planId.length; i++) {
      Long planid = planId[i];
      PlanEntity planEntity = planRepository.findById(planid).orElse(null);
      detailList.add(planEntity);
    }
    return detailList;
  }
//
//  // 세부일정 보기
//  public List<PlanDetailEntity> findByPlanId(Long planId) {
//    List<PlanDetailEntity> detailList = planDetailrep.findByPlanId(@Param("planId") Long planid);
//    return detailList;
//  }

  public PlanEntity findPlanById(Long planId) {
    // TODO Auto-generated method stub
    return planRepository.findById(planId).orElse(null);
  }

}
