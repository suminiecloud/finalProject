package kr.co._icia.finalProject.socket.files.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlanDetailDto {

  private String vehicle; // 교통 수단
  private String keyword; // 키워드
  private String generation;// 이용 연령
  private String gender; // 성별
  private String detaildate;// 여행일 중 하루

}
