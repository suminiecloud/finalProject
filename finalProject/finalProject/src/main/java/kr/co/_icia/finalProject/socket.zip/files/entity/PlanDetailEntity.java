package kr.co._icia.finalProject.socket.files.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import kr.co._icia.finalProject.entity.Members;
import kr.co._icia.finalProject.socket.files.dto.PlanDetailDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "PLANDETAIL")
public class PlanDetailEntity {

  @Id
  @GeneratedValue
  private Long id;

  private String vehicle; // 교통 수단
  private String keyword; // 키워드
  private String generation;// 이용 연령
  private String gender; // 성별
  private String detaildate;// 여행일 중 하루
  
  @ManyToOne
  @JoinColumn(name = "member_id")
  private Members member;
  
  @ManyToOne
  @JoinColumn(name = "plan_id")
  private PlanEntity plan;

  public static PlanDetailEntity createPlan(PlanDetailDto planDetail, Members members, PlanEntity planEntity) {
    PlanDetailEntity planDetailEntity = new PlanDetailEntity();
    planDetailEntity.setVehicle(planDetail.getVehicle());
    planDetailEntity.setKeyword(planDetail.getKeyword());
    planDetailEntity.setGeneration(planDetail.getGeneration());
    planDetailEntity.setGender(planDetail.getGender());
    planDetailEntity.setDetaildate(planDetail.getDetaildate());
    planDetailEntity.setMember(members);
    planDetailEntity.setPlan(planEntity);
    return planDetailEntity;
  }

}
